exports.handler = (event, context) => {
	context.succeed('placeholder');
};
